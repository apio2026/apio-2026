#include "ancient.h"
#include <cstdio>
#include <vector>
#include <utility>
#include <string>
#include <cassert>

namespace {
    const int MAXQ = 700;
    const long long QUERY_C = 1'000'000'000'000'000'000;
    int N, S;
    int Q;
    std::vector<int> P;
    std::vector<int> H;
    std::vector<std::vector<int>> adjacent_towers;
    void init_testcase() {
        Q = 0;
        P = std::vector<int>(N);
        H = std::vector<int>(N);
        adjacent_towers = std::vector<std::vector<int>>(N);
    }
    void wrong_answer(const std::string &msg) {
        printf("Wrong Answer: %s\n", msg.c_str());
        exit(0);
    }
}

std::vector<int> detect_convenience_values(const std::vector<long long> &D) {
    if (int(D.size()) != N)
        wrong_answer("invalid call");
    for (int i = 0; i < N; i++) {
        if (D[i] < -QUERY_C || D[i] > QUERY_C)
            wrong_answer("invalid call");
    }
    if (Q >= MAXQ)
        wrong_answer("too many queries");
    Q++;
    std::vector<int> ret(N);
    for (int i = 0; i < N; i++) {
        for (int j : adjacent_towers[i]) {
            if ((H[j] + D[j] < H[i] + D[i]) || (j == P[i] && H[j] + D[j] == H[i] + D[i])) {
                ret[i]++;
            }
        }
    }
    return ret;
}

int main() {
    int T;
    assert(scanf("%d", &T) == 1);
    for (int testcase = 0; testcase < T; testcase++) {
        assert(scanf("%d %d", &N, &S) == 2);
        init_testcase();
        for (int i = 1; i < N; i++) {
            assert(scanf("%d", &P[i]) == 1);
            assert(P[i] < i);
            adjacent_towers[P[i]].emplace_back(i);
            adjacent_towers[i].emplace_back(P[i]);
        }
        for (int i = 0; i < N; i++) {
            assert(scanf("%d", &H[i]) == 1);
        }

        auto [ret_P, ret_D] = find_information(N, S);
        if ((int)ret_P.size() != N - 1 || (int)ret_D.size() != N - 1)
            wrong_answer("incorrect answer");
        for (int i = 1; i < N; i++) {
            if (ret_P[i - 1] != P[i])
                wrong_answer("incorrect answer");
            if (ret_D[i - 1] != H[i] - H[0])
                wrong_answer("incorrect answer");
        }
        printf("Accepted: %d\n", Q);
    }
}
