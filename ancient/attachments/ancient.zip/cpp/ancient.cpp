#include "ancient.h"

#include <iostream>

void print_array(const std::vector<int> &v) {
    std::cerr << "return:";
    for (int i : v) std::cerr << " " << i;
    std::cerr << "\n";
}

std::pair<std::vector<int>, std::vector<int>> find_information(int N, int S) {
    std::vector<int> P(N), R(N);

    if (N == 5) {
        for (int i = 1; i < N; i++) P[i] = i - 1;
        R = {0, 4, 5, 3, -1};
        
        print_array(detect_convenience_values({1, 0, -3, 0, 4}));
        print_array(detect_convenience_values({6, 0, 0, 0, 0}));
        print_array(detect_convenience_values({0, 1, 0, 0, 4}));
    }
    else {
        P = {0, 0, 0, 1, 1, 2, 2};
        R = {0, -2, 1, -2, 2, 6, -1};
        
        print_array(detect_convenience_values({0, 0, 0, 0, 0, 0, 0}));
        print_array(detect_convenience_values({0, 2, -1, 2, -2, -6, 1}));
        print_array(detect_convenience_values({-2, 0, 0, 0, 0, 0, 0}));
    }


    return std::make_pair(std::vector<int>(P.begin() + 1, P.end()), 
                          std::vector<int>(R.begin() + 1, R.end()));
}
