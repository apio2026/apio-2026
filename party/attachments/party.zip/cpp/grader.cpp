#include "party.h"

#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <system_error>
#include <tuple>
#include <utility>
#include <vector>

#if defined(_WIN32) || defined(_WIN64)
#include <process.h>
#else
#include <unistd.h>
#endif

namespace {
std::fstream record;

[[noreturn]] static void die(const std::string &message) {
  std::puts(message.c_str());
  record.close();
  exit(0);
}

void print_array(std::vector<int> arr) {
  std::fprintf(stderr, "[");
  for (int i = 0; i < (int)arr.size(); i++)
    std::fprintf(stderr, "%d%s", arr[i], i + 1 == arr.size() ? "]" : ", ");
}
} // namespace

int main(int argc, char *argv[]) {
  std::setvbuf(stdin, nullptr, _IONBF, 0);

  std::filesystem::path program_path;
  {
    std::error_code ec;
    auto path = std::filesystem::current_path(ec);
    if (ec) {
      std::cerr << "cannot get current path:\n";
      std::cerr << ec << '\n';
      std::abort();
    }
    if (argc == 0) {
      std::cerr << "cannot determine the executable path; please run from "
                   "run.sh or a shell if possible\n";
      std::abort();
    }
    program_path = path / argv[0];
    if (!std::filesystem::exists(program_path) ||
        !std::filesystem::is_regular_file(program_path)) {
      std::cerr << "cannot determine the executable path; please run from "
                   "run.sh or a shell if possible\n";
      std::abort();
    }
  }

  int N, K;
  std::vector<int> P, F;
  int reveal;
  if (argc == 1 || argv[1] != std::string("run")) {
    record.open("pizza.bin", std::ios::binary | std::ios::trunc | std::ios::out |
                                std::ios::in);

    assert(scanf("%d%d", &N, &K) == 2);
    P.resize(N);
    F.resize(N * N);
    for (int i = 0; i < N; i++)
      assert(scanf("%d", &P[i]) == 1);
    for (int i = 0; i < N * N; i++)
      assert(scanf("%d", &F[i]) == 1);
    assert(scanf("%d", &reveal) == 1);

    record.write(reinterpret_cast<char *>(&N), sizeof(int));
    record.write(reinterpret_cast<char *>(&K), sizeof(int));
    for (int i = 0; i < N; i++)
      record.write(reinterpret_cast<char *>(&P[i]), sizeof(int));
    for (int i = 0; i < N * N; i++)
      record.write(reinterpret_cast<char *>(&F[i]), sizeof(int));
    record.write(reinterpret_cast<char *>(&reveal), sizeof(int));
    record.seekg(0, std::ios_base::end);
  } else {
    record.open("pizza.bin", std::ios::binary | std::ios::out | std::ios::in);

    record.read(reinterpret_cast<char *>(&N), sizeof(int));
    record.read(reinterpret_cast<char *>(&K), sizeof(int));
    P.resize(N);
    F.resize(N * N);
    for (int i = 0; i < N; i++)
      record.read(reinterpret_cast<char *>(&P[i]), sizeof(int));
    for (int i = 0; i < N * N; i++)
      record.read(reinterpret_cast<char *>(&F[i]), sizeof(int));
    record.read(reinterpret_cast<char *>(&reveal), sizeof(int));
  }

  std::vector<int> S(N * N);

  int i; // room index
  if (record.peek() == std::char_traits<char>::eof()) {
    record.clear();
    record.seekg(0, std::ios_base::end);
    i = 0;
    for (int b = 0; b < N * N; b++)
      S[b] = K;
  } else {
    record.read(reinterpret_cast<char *>(&i), sizeof(int));
    i++;
    for (int b = 0; b < N * N; b++)
      record.read(reinterpret_cast<char *>(&S[b]), sizeof(int));
  }

  if (i < N) {
    std::fprintf(stderr, "===== Room %d =====\n", i);
    int r;
    if (reveal == 0)
      r = -1;
    else
      r = i;

    std::fprintf(stderr, "init(%d, %d, %d, %d)\n", N, K, P[i], r);
    init(N, K, P[i], r);

    for (int b = 0; b < N * N; b++) {
      std::fprintf(stderr, "strategy(%d, %d, %d)\n", b, F[b], S[b]);
      int x = strategy(b, F[b], S[b]);
      if (F[b] == P[i] && x > 0)
        die("Participant ate slices when C[b] = P[i]");
      if (x < 0 || x > S[b])
        die("Participant ate an invalid number of slices");
      S[b] -= x;
    }

    record.seekp((N * N + N + 3) * 4);
    record.write(reinterpret_cast<char *>(&i), sizeof(int));
    for (int b = 0; b < N * N; b++)
      record.write(reinterpret_cast<char *>(&S[b]), sizeof(int));
    record.flush();
    record.close();

#if defined(_WIN32) || defined(_WIN64)
    int err = _execl(program_path.string().c_str(), argv[0], "run", nullptr);
#else
    int err = execl(program_path.c_str(), argv[0], "run", nullptr);
#endif
    die("unable to restart the program");
  } else {
    std::fprintf(stderr, "===== Guests outside =====\n");
    std::fprintf(stderr, "guess(%d, %d, ", N, K);
    print_array(F);
    std::fprintf(stderr, ", ");
    print_array(S);
    std::fprintf(stderr, ")\n");
    std::vector<int> Q = guess(N, K, F, S);
    if (Q == P) {
      std::printf("Accepted\n");
      std::exit(0);
    } else {
      die("Guessed permutation is incorrect");
    }
  }
}