#include "party.h"

namespace {
    // store global variables here
    int room = 0;
    std::vector<int> P = {0, 2, 1};
} // namespace

void init(int N, int K, int p, int r) {
    room = r;
    return;
}

int strategy(int b, int f, int s) {
    return 0;
}

std::vector<int> guess(int N, int K, std::vector<int> F, std::vector<int> S) {
    return P;
}
