#include "nightmarket.h"
#include <cassert>
#include <cstdio>

int main()
{
  int N, M;
  assert(scanf("%d", &N) == 1);
  assert(scanf("%d", &M) == 1);
  std::vector<std::vector<int>> S(N, std::vector<int>(M));
  for (int i = 0; i < N; i++)
    for (int j = 0; j < M; j++)
      assert(scanf("%d", &S[i][j]) == 1);
  fclose(stdin);

  std::vector<std::string> P = find_sequences(N, M, S);

  printf("%d\n", (int)P.size());
  for (size_t i = 0; i < P.size(); i++)
    printf("%s\n", P[i].c_str());
  fclose(stdout);

  return 0;
}
