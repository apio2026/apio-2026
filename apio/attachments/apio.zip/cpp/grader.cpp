#include "apio.h"
#include <string>
#include <cassert>

int main() {
    int n, k;
    assert(scanf("%d %d", &n, &k) == 2);
    int max_len = 0;
    for (int i = 0; i < n; ++i) {
        int x;
        assert(scanf("%d", &x) == 1);
        
        std::string msg = Alice(x, k);

        if ((int)msg.size() > 120) {
            printf("Wrong Answer: Encoding exceeds maximum allowed length\n");
            exit(0);
        }

        for (auto c : msg)
            if (c != 'O' && c != 'I') {
                printf("Wrong Answer: Invalid encoding\n");
                exit(0);
            }

        for (int iter = 0; iter < k; ++iter) {
            for (int j = 0; j < (int)msg.size() - 1; ++j) {
                if (msg[j] == 'O' && msg[j + 1] == 'I') {
                    std::swap(msg[j], msg[j + 1]);
                    break;
                }
            }
        }

        int y = Bob(msg, k);
        if (x != y) {
            printf("Wrong Answer: Incorrect answer\n");
            exit(0);
        }

        max_len = std::max(max_len, (int)msg.size());
    }

    printf("Accepted: %d\n", max_len);
}