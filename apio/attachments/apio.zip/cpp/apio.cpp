#include "apio.h"
#include <string>
#include <algorithm>

std::string Alice(int x, int k) {
    return std::string(x, 'O');
}

int Bob(std::string s, int k) {
    return (int)std::count(s.begin(), s.end(), 'O');
}
