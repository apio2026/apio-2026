#include "navigation.h"

namespace {
// you can store information in the global scope,
// but construct_network and navigate run in different process; they won't be able to share the data
int count = 0;
} // namespace

std::vector<int> construct_network(int N, int K, int B, std::vector<int> U,
                                   std::vector<int> V, std::vector<int> P) {
  return {0, 10, 1, 2, 3, 4, 5, 5};
}

std::vector<int> navigate(int K, int B, std::vector<int> C) {
  count++;

  if (count == 1)
    return {1, 4, 1};
  else if (count == 2)
    return {2, 1, 1, 1, 1};

  return {};
}
