#include "bike.h"

std::pair<std::vector<int>, std::vector<long long>>
        find_rebalancing_strategy(int N, 
                                  std::vector<int> A, 
                                  std::vector<int> B, 
                                  std::vector<int> U,
                                  std::vector<int> V) {
    std::vector<int> X = {0};
    std::vector<long long> Y = {-1};
    return {X, Y};
}
