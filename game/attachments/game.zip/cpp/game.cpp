#include "game.h"

namespace {

int id;
bool remembered;

} // namespace

int start_game(int L, int N, int i) {
  id = i;
  return 2;
}

std::vector<bool> leader(std::vector<bool> c) {
  return {!c[0], !c[1]};
}

std::vector<bool> student_first(std::vector<bool> c) {
  c[id - 1] = !c[id - 1];
  remembered = c[id - 1];
  return c;
}

std::pair<bool, std::vector<bool>> student_second(std::vector<bool> c) {
  return {c[id - 1] != remembered, c};
}