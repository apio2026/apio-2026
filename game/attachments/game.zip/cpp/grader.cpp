#include "game.h"

#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <system_error>
#include <tuple>
#include <utility>
#include <vector>

#if defined(_WIN32) || defined(_WIN64)
#include <process.h>
#else
#include <unistd.h>
#endif

namespace {
std::fstream record;

[[noreturn]] static void die(const std::string &message) {
  std::puts(message.c_str());
  record.close();
  exit(0);
}

std::vector<bool> to_array(std::uint64_t state, int K) {
  std::vector<bool> res(K);
  for (int i = 0; i < K; i++)
    res[i] = state & (1ull << i);
  return res;
}
std::uint64_t from_array(std::vector<bool> arr) {
  std::uint64_t state = 0;
  for (int i = 0; i < (int)arr.size(); i++)
    state ^= (std::uint64_t)arr[i] << i;
  return state;
}
void print_array(std::vector<bool> arr) {
  std::fprintf(stderr, "[");
  for (int i = 0; i < (int)arr.size(); i++)
    std::fprintf(stderr, "%d%s", (int)arr[i], i + 1 == arr.size() ? "]" : ", ");
}
} // namespace

int main(int argc, char *argv[]) {
  std::setvbuf(stdin, nullptr, _IONBF, 0);

  std::filesystem::path program_path;
  {
    std::error_code ec;
    auto path = std::filesystem::current_path(ec);
    if (ec) {
      std::cerr << "cannot get current path: ";
      std::cerr << ec << '\n';
      std::abort();
    }
    if (argc == 0) {
      std::cerr << "cannot determine the executable path; please run from "
                   "run.sh or a shell if possible\n";
      std::abort();
    }
    program_path = path / argv[0];
    if (!std::filesystem::exists(program_path) ||
        !std::filesystem::is_regular_file(program_path)) {
      std::cerr << "cannot determine the executable path; please run from "
                   "run.sh or a shell if possible\n";
      std::abort();
    }
  }

  int L, N, M, K;
  if (argc == 1 || argv[1] != std::string("run")) {
    record.open("game.bin", std::ios::binary | std::ios::trunc | std::ios::out |
                                std::ios::in);

    assert(scanf("%d%d%d", &L, &N, &M) == 3);

    record.write(reinterpret_cast<char *>(&L), sizeof(int));
    record.write(reinterpret_cast<char *>(&N), sizeof(int));
    record.write(reinterpret_cast<char *>(&M), sizeof(int));
    record.seekg(0, std::ios_base::end);
  } else {
    record.open("game.bin", std::ios::binary | std::ios::out | std::ios::in);
    record.read(reinterpret_cast<char *>(&L), sizeof(int));
    record.read(reinterpret_cast<char *>(&N), sizeof(int));
    record.read(reinterpret_cast<char *>(&M), sizeof(int));
    record.read(reinterpret_cast<char *>(&K), sizeof(int));
  }

  std::vector<std::pair<int, std::uint64_t>> states;

  int i = 0;
  for (; i < M; i++) {
    int id;
    std::uint64_t state;
    if (record.peek() == std::char_traits<char>::eof()) {
      record.clear();
      record.seekg(0, std::ios_base::end);
      break;
    }
    record.read(reinterpret_cast<char *>(&id), sizeof(int));
    record.read(reinterpret_cast<char *>(&state), sizeof(std::uint64_t));

    states.emplace_back(std::make_pair(id, state));
  }

  if (i == M) {
    std::printf("Accepted, %d\n", K);
    std::exit(0);
  }


  // current step unprocessed
  int id;
  std::uint64_t state = 0;
  assert(scanf("%d", &id) == 1);
  std::fprintf(stderr, "===== run %d, student %d =====\n", i, id);

  std::fprintf(stderr, "start_game(%d, %d, %d)\n", L, N, id);
  if (i == 0) {
    K = start_game(L, N, id);
    if (K < 0 || 64 < K)
      die("invalid K");
    record.write(reinterpret_cast<char *>(&K), sizeof(int));
    record.seekg(0, std::ios_base::end);
  } else if (K != start_game(L, N, id))
    die("inconsistent K");

  int called = 0;
  bool answer = false;
  for (auto [prev_id, prev_state] : states) {
    if (prev_id == id) {
      std::vector<bool> c = to_array(state, K);
      std::vector<bool> ret;
      if (id == 0) {
        std::fprintf(stderr, "leader(");
        print_array(c);
        std::fprintf(stderr, ")\n");

        ret = leader(c);
      } else if (!called) {
        std::fprintf(stderr, "student_first(");
        print_array(c);
        std::fprintf(stderr, ")\n");

        ret = student_first(c);
      } else if (called)
        die("invalid input: non-leader student called for more than 2 times");

      if ((int)ret.size() != K)
        die("returned array size is not K");

      std::uint64_t ret_state = from_array(ret);
      if (ret_state != prev_state)
        die("returned array inconsistent");
      called++;
    }
    if (called && prev_id == 0 && id > 0)
      answer = true;
    state = prev_state;
  }

  std::vector<bool> c = to_array(state, K);
  std::vector<bool> ret;
  if (id == 0) {
    if (called >= L)
        die("invalid input: leader student called for more than L times");
    std::fprintf(stderr, "leader(");
    print_array(c);
    std::fprintf(stderr, ")\n");

    ret = leader(c);
  } else if (!called) {
    std::fprintf(stderr, "student_first(");
    print_array(c);
    std::fprintf(stderr, ")\n");
    ret = student_first(c);
  } else if (called) {
    std::fprintf(stderr, "student_second(");
    print_array(c);
    std::fprintf(stderr, ")\n");

    bool res;
    std::tie(res, ret) = student_second(c);
    if (res != answer)
      die("student second run answer incorrect");
  }

  if ((int)ret.size() != K)
    die("returned array is not size K");

  state = from_array(ret);
  record.seekp(0, std::ios_base::end);
  record.write(reinterpret_cast<char *>(&id), sizeof(int));
  record.write(reinterpret_cast<char *>(&state), sizeof(std::uint64_t));
  record.flush();
  record.close();

#if defined(_WIN32) || defined(_WIN64)
  int err = _execl(program_path.c_str(), argv[0], "run", nullptr);
#else
  int err = execl(program_path.c_str(), argv[0], "run", nullptr);
#endif
  die("unable to restart the program");
}